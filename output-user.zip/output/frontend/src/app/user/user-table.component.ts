import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';

@Component({
  selector: 'app-user-table',
  templateUrl: './user-table.component.html'
})
export class UserTableComponent implements OnInit {
  users: any[] = [];

  constructor(private service: UserService) {}

  ngOnInit(): void {
    this.service.getAll().subscribe(data => {
      this.users = data;
    });
  }
}
