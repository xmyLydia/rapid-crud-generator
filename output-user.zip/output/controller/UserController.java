package com.rapidcrud.generator.controller;

import com.rapidcrud.generator.repository.UserRepository;
import com.rapidcrud.generator.entity.User;
import org.springframework.web.bind.annotation.*;
import java.util.*;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class UserController {

    private final UserRepository repository;

    @GetMapping
    public List<User> getAll() {
        return repository.findAll();
    }

    @PostMapping
    public User create(@RequestBody User entity) {
        return repository.save(entity);
    }
}
