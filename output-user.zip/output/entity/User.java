package com.rapidcrud.generator.entity;

import lombok.Data;
import java.time.*;
// Class: User
// Fields: 4 field(s)
@Data
public class User {
    private Long id;
    private String name;
    private String email;
    private LocalDateTime createdAt;
}
