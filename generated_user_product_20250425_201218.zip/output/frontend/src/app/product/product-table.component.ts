import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';

@Component({
  selector: 'app-product-table',
  templateUrl: './product-table.component.html'
})
export class ProductTableComponent implements OnInit {
  products: any[] = [];

  constructor(private service: ProductService) {}

  ngOnInit(): void {
    this.service.getAll().subscribe((data: any[]) => {
      this.products = data;
    });
  }
}
