import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { UserService } from './user.service';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html'
})
export class UserFormComponent {
  form: FormGroup;

  constructor(private fb: FormBuilder, private service: UserService) {
    this.form = this.fb.group({
      id: [''],
      name: [''],
    });
  }

  submit(): void {
    this.service.create(this.form.value).subscribe();
  }
}
