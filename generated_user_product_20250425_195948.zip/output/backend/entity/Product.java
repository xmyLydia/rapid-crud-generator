package com.rapidcrud.generator.entity;

import lombok.Data;
import java.time.*;
// Class: Product
// Fields: 3 field(s)
@Data
public class Product {
    private Long id;
    private String title;
    private Double price;
}
