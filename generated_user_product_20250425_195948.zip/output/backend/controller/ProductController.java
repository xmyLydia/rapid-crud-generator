package com.rapidcrud.generator.controller;

import com.rapidcrud.generator.repository.ProductRepository;
import com.rapidcrud.generator.entity.Product;
import org.springframework.web.bind.annotation.*;
import java.util.*;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/product")
@RequiredArgsConstructor
public class ProductController {

    private final ProductRepository repository;

    @GetMapping
    public List<Product> getAll() {
        return repository.findAll();
    }

    @PostMapping
    public Product create(@RequestBody Product entity) {
        return repository.save(entity);
    }
}
