import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ProductService } from './product.service';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html'
})
export class ProductFormComponent {
  form: FormGroup;

  constructor(private fb: FormBuilder, private service: ProductService) {
    this.form = this.fb.group({
      id: [''],
      title: [''],
      price: [''],
    });
  }

  submit(): void {
    this.service.create(this.form.value).subscribe();
  }
}
