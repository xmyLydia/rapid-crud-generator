import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { ProductTableComponent } from './product-table.component';
import { ProductFormComponent } from './product-form.component';

@NgModule({
  declarations: [
    ProductTableComponent,
    ProductFormComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule
  ]
})
export class ProductModule {}
